<?php 
    header("Content-Type:application/json");    
    $conn= mysqli_connect("w.rdc.sae.sina.com.cn","kklj10wl4z","x425k5jlkhlhx15zkz5k302l5y4mkmmj2hmjxkyl","app_kkkjjuhgh",3306);
    $sql="SET NAMES UTF8";
    mysqli_query($conn,$sql);
?>